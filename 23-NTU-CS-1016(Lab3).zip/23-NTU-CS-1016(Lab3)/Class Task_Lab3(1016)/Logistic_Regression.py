import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Load dataset
data = pd.read_csv('Social_Network_Ads.csv')

# Preprocessing
data = pd.get_dummies(data, columns=['Gender'], drop_first=True)

# Features and target
X = data[['Gender_Male', 'Age', 'EstimatedSalary']].values
y = data['Purchased'].values

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scale features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


# Logistic Regression from scratch
class LogisticRegression:

    def __init__(self, learning_rate=0.01, num_iterations=1000):
        self.lr = learning_rate
        self.iterations = num_iterations
        self.weights = None
        self.bias = None

    def sigmoid(self, z):
        return 1 / (1 + np.exp(-z))

    def fit(self, X, y):

        num_samples, num_features = X.shape

        self.weights = np.zeros(num_features)
        self.bias = 0

        for i in range(self.iterations):

            linear_model = np.dot(X, self.weights) + self.bias

            y_predicted = self.sigmoid(linear_model)

            # Calculate gradient
            dw = (1 / num_samples) * np.dot(
                X.T, (y_predicted - y)
            )

            db = (1 / num_samples) * np.sum(
                y_predicted - y
            )

            # Update weights and bias
            self.weights -= self.lr * dw
            self.bias -= self.lr * db

    def predict(self, X):

        linear_model = np.dot(X, self.weights) + self.bias

        return [
            1 if i > 0.5 else 0
            for i in self.sigmoid(linear_model)
        ]


# Train model
model = LogisticRegression(
    learning_rate=0.1,
    num_iterations=1000
)

model.fit(X_train, y_train)

# Predictions
predictions = model.predict(X_test)

# Evaluation
print("Accuracy:", accuracy_score(y_test, predictions))

print("Confusion Matrix:")
print(confusion_matrix(y_test, predictions))

print("Classification Report:")
print(classification_report(y_test, predictions))